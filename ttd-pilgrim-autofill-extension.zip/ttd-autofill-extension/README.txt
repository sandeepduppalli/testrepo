TTD Pilgrim Autofill — private local browser extension

1. In Microsoft Edge, open edge://extensions
2. Turn on Developer mode (usually at the lower-left or upper-right).
3. Select “Load unpacked”.
4. Choose this entire “ttd-autofill-extension” folder.
5. Optionally pin “My TTD Pilgrim Autofill” from the Extensions menu.
6. Click the extension icon once to enter and save up to six pilgrims. Use Add pilgrim or Remove last to adjust the list.
7. On the official TTD Pilgrim Details page, click the extension icon and then “Fill TTD form”.
   If you update this folder later, click the reload symbol on the extension card in edge://extensions.

The extension stores its information only in your browser profile. When you press Fill TTD form, it types only into the open official TTD page; it does not submit a form. Always review the filled details; OTPs, CAPTCHAs, payment, and the Continue button remain yours to handle.
