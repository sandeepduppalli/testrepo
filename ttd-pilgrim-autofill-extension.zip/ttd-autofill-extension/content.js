// Runs only when the user presses Fill TTD form. It does not submit a booking.
const normal = s => (s || '').replace(/\s+/g,' ').trim().toLowerCase();
const fire = (el, type) => el.dispatchEvent(new Event(type,{bubbles:true}));
function editable(root) { return [...root.querySelectorAll('input,textarea,[contenteditable="true"]')].find(e => !e.disabled); }
function allFieldRoots() { return [...new Set([...document.querySelectorAll('input,select,textarea,mat-select,[role="combobox"]')].map(el => el.closest('mat-form-field,.mat-mdc-form-field,.form-group,.field') || el.parentElement))]; }
function rootsFor(text) { return allFieldRoots().filter(r => normal(r.innerText).includes(text)); }
function setText(el,value) { if (!el || !value) return false; const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set; setter ? setter.call(el,value) : el.value=value; fire(el,'input');fire(el,'change');fire(el,'blur');return true; }
function pick(root,value) { if (!root || !value) return false; const select=root.querySelector('select'); if(select){ const opt=[...select.options].find(o=>normal(o.text).includes(normal(value))); if(opt){select.value=opt.value;fire(select,'change');return true;} } const trigger=root.querySelector('[role="combobox"],.mat-mdc-select-trigger,.mat-select-trigger'); if(trigger){trigger.click();setTimeout(()=>{const option=[...document.querySelectorAll('mat-option,[role="option"]')].find(o=>normal(o.textContent).includes(normal(value)));option?.click();},150);return true;} return false; }
chrome.runtime.onMessage.addListener((message,_sender,reply)=>{
 if(message.type!=='fill') return;
 chrome.storage.local.get({pilgrims:[]}, ({pilgrims}) => {
   const names=rootsFor('name'), ages=rootsFor('age'), genders=rootsFor('gender'), proofs=rootsFor('photo id proof'), numbers=rootsFor('photo id number');
   let filled=0;
   pilgrims.forEach((p,i)=>{ filled+=setText(editable(names[i]),p.name)?1:0; filled+=setText(editable(ages[i]),p.age)?1:0; filled+=pick(genders[i],p.gender)?1:0; filled+=pick(proofs[i],p.idType)?1:0; filled+=setText(editable(numbers[i]),p.idNumber)?1:0; });
   reply({message: filled ? `Filled ${filled} field(s). Check details before continuing.` : 'No matching fields found. Use this on the Pilgrim Details page.'});
 });
 return true;
});
