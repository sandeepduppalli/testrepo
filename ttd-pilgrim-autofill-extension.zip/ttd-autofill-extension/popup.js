const idTypes = ['Aadhaar','PAN','Passport','Voter ID','Driving Licence'];
const genders = ['Male','Female','Other'];
const people = document.querySelector('#people');
const MAX_PILGRIMS = 6;
let pilgrimCount = 1;
const person = (i) => `<div class="person"><strong>Pilgrim ${i+1}</strong><label class="include"><input data-p="${i}" data-k="enabled" type="checkbox" checked> Include when filling</label><label>Name<input data-p="${i}" data-k="name"></label><label>Age<input data-p="${i}" data-k="age" inputmode="numeric"></label><label>Gender<select data-p="${i}" data-k="gender"><option value=""></option>${genders.map(x=>`<option>${x}</option>`).join('')}</select></label><label>Photo ID proof<select data-p="${i}" data-k="idType"><option value=""></option>${idTypes.map(x=>`<option>${x}</option>`).join('')}</select></label><label>Photo ID number<input data-p="${i}" data-k="idNumber"></label></div>`;
const getEls = () => [...document.querySelectorAll('[data-p]')];
const render = (data=[]) => { people.innerHTML = Array.from({length:pilgrimCount}, (_, i) => person(i)).join(''); getEls().forEach(e => { const value=data?.[+e.dataset.p]?.[e.dataset.k]; if(e.type==='checkbox') e.checked=value !== false; else e.value=value || ''; }); document.querySelector('#add').disabled = pilgrimCount === MAX_PILGRIMS; document.querySelector('#remove').disabled = pilgrimCount === 1; };
render();
const status = msg => document.querySelector('#status').textContent = msg;
const read = () => Array.from({length:pilgrimCount}, (_,p) => Object.fromEntries(getEls().filter(e=>+e.dataset.p===p).map(e=>[e.dataset.k,e.type==='checkbox' ? e.checked : e.value.trim()])));
chrome.storage.local.get({pilgrims:[]}, x => { pilgrimCount=Math.max(1,Math.min(MAX_PILGRIMS,x.pilgrims.length || 1)); render(x.pilgrims); });
document.querySelector('#add').onclick = () => { if(pilgrimCount < MAX_PILGRIMS) { const data=read(); pilgrimCount++; render(data); } };
document.querySelector('#remove').onclick = () => { if(pilgrimCount > 1) { const data=read(); pilgrimCount--; render(data); } };
document.querySelector('#save').onclick = () => chrome.storage.local.set({pilgrims:read()}, () => status('Saved only in this browser.'));
async function fillTtd(pilgrims) {
  const norm = x => (x || '').replace(/\s+/g,' ').trim().toLowerCase();
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  const roots = [...new Set([...document.querySelectorAll('mat-form-field,.mat-mdc-form-field')])];
  const matches = label => roots.filter(root => norm(root.innerText).includes(label));
  const input = root => root?.matches?.('input,textarea') ? root : root?.querySelector('input,textarea');
  const setText = async (root, value) => {
    const el = input(root); if (!el || !value) return false;
    el.focus();
    const previous = el.value;
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value')?.set || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
    setter ? setter.call(el, value) : el.value = value;
    // React tracks input values internally. Resetting this tracker makes its
    // onChange handler accept a value supplied by the extension.
    if (el._valueTracker) el._valueTracker.setValue(previous);
    el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));
    for (const type of ['change','keyup','blur']) el.dispatchEvent(new Event(type,{bubbles:true}));
    await wait(80);
    return el.value === value;
  };
  const choose = async (root, value) => {
    if (!root || !value) return false;
    const labelledInput = root.matches?.('input[readonly]') ? root : null;
    if (labelledInput) {
      labelledInput.click(); await wait(140);
      const option=[...document.querySelectorAll('li,button,div,span')].find(el => el.getClientRects().length && norm(el.textContent) === norm(value) && !el.querySelector('li,button,div,span'));
      if (option) { option.click(); await wait(120); return norm(labelledInput.value) === norm(value); }
      return setText(labelledInput,value);
    }
    const native = root.querySelector('select');
    if (native) { const opt=[...native.options].find(o=>norm(o.text).includes(norm(value))); if (!opt) return false; native.value=opt.value; native.dispatchEvent(new Event('change',{bubbles:true})); return true; }
    const trigger = root.matches?.('mat-select,.mat-mdc-select-trigger,.mat-select-trigger,[role="combobox"]') ? root : root.querySelector('mat-select,.mat-mdc-select-trigger,.mat-select-trigger,[role="combobox"]');
    if (!trigger) return false;
    trigger.click(); await wait(180);
    const option = [...document.querySelectorAll('mat-option,.mat-mdc-option,[role="option"]')].find(o => norm(o.textContent).includes(norm(value)));
    if (!option) return false; option.click(); await wait(120); return true;
  };
  const labelled = label => [...document.querySelectorAll(`input[label="${label}"],textarea[label="${label}"]`)];
  const names=labelled('Name').length ? labelled('Name') : matches('name');
  const ages=labelled('Age').length ? labelled('Age') : matches('age');
  const genders=labelled('Gender').length ? labelled('Gender') : matches('gender');
  const proofs=labelled('Photo ID proof').length ? labelled('Photo ID proof') : matches('photo id proof');
  const numbers=labelled('Photo ID number').length ? labelled('Photo ID number') : matches('photo id number');
  // TTD sometimes renders labels outside the Material control. In that layout,
  // every pilgrim repeats Name, Age, Gender, ID proof, and ID number in order.
  const visibleInputs=[...document.querySelectorAll('input,textarea')].filter(el => el.type !== 'hidden' && !el.disabled && el.getClientRects().length);
  const dropdowns=[...document.querySelectorAll('mat-select,.mat-mdc-select-trigger,.mat-select-trigger,[role="combobox"]')].filter(el => el.getClientRects().length).filter((el,i,a)=>a.findIndex(x => x.closest('mat-form-field,.mat-mdc-form-field') === el.closest('mat-form-field,.mat-mdc-form-field')) === i);
  let filled=0;
  for (let i=0;i<pilgrims.length;i++) {
    const p=pilgrims[i]; const base=i*3, selectBase=i*2;
    filled += await setText(names[i] || visibleInputs[base],p.name)?1:0;
    filled += await setText(ages[i] || visibleInputs[base+1],p.age)?1:0;
    filled += await choose(genders[i] || dropdowns[selectBase],p.gender)?1:0;
    filled += await choose(proofs[i] || dropdowns[selectBase+1],p.idType)?1:0;
    filled += await setText(numbers[i] || visibleInputs[base+2],p.idNumber)?1:0;
  }
  return {filled, found:{name:names.length,age:ages.length,gender:genders.length,proof:proofs.length,id:numbers.length}};
}
// TTD ignores programmatic value changes. This route uses the browser's normal
// keyboard and pointer events on the current tab, exactly as a user would.
async function fillWithKeyboard(tabId, pilgrims) {
  const target = {tabId};
  const send = (method, params = {}) => chrome.debugger.sendCommand(target, method, params);
  const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
  const evaluate = async expression => (await send('Runtime.evaluate', {expression, returnByValue:true})).result?.value;
  const pointFor = (label, index) => evaluate(`(() => { const label=${JSON.stringify(label)}.toLowerCase(); const els=[...document.querySelectorAll('input')].filter(e => (e.getAttribute('label')||'').toLowerCase()===label); const el=els[${index}]; if(!el) return null; el.scrollIntoView({block:'center',inline:'center'}); const r=el.getBoundingClientRect(); return {x:r.left+r.width/2,y:r.top+r.height/2}; })()`);
  const optionPoint = value => evaluate(`(() => { const want=${JSON.stringify(value)}.trim().toLowerCase(); const els=[...document.querySelectorAll('li,button,div,span,[role="option"]')].map(e => ({e,r:e.getBoundingClientRect(),text:(e.textContent||'').trim().toLowerCase()})).filter(x => x.text && x.r.width && x.r.height && (x.text===want || x.text.startsWith(want))).sort((a,b) => (a.r.width*a.r.height)-(b.r.width*b.r.height)); const hit=els[0]; if(!hit) return null; return {x:hit.r.left+hit.r.width/2,y:hit.r.top+hit.r.height/2}; })()`);
  const click = async point => { if(!point) return false; await send('Input.dispatchMouseEvent',{type:'mousePressed',x:point.x,y:point.y,button:'left',clickCount:1}); await send('Input.dispatchMouseEvent',{type:'mouseReleased',x:point.x,y:point.y,button:'left',clickCount:1}); return true; };
  const type = async (label,index,value) => { if(!value) return false; const point=await pointFor(label,index); if(!await click(point)) return false; await send('Input.dispatchKeyEvent',{type:'rawKeyDown',key:'a',code:'KeyA',modifiers:4}); await send('Input.dispatchKeyEvent',{type:'keyUp',key:'a',code:'KeyA',modifiers:4}); await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Backspace',code:'Backspace'}); await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Backspace',code:'Backspace'}); await send('Input.insertText',{text:String(value)}); return true; };
  const select = async (label,index,value) => { if(!value) return false; if(!await click(await pointFor(label,index))) return false; await pause(300); const chosen=await click(await optionPoint(value)); if(chosen) await pause(250); return chosen; };
  await chrome.debugger.attach(target, '1.3');
  try {
    let filled=0;
    for(let i=0;i<pilgrims.length;i++) { const p=pilgrims[i]; filled += await type('Name',i,p.name)?1:0; filled += await type('Age',i,p.age)?1:0; filled += await select('Gender',i,p.gender)?1:0; filled += await select('Photo ID proof',i,p.idType)?1:0; filled += await type('Photo ID number',i,p.idNumber)?1:0; }
    return filled;
  } finally { await chrome.debugger.detach(target).catch(()=>{}); }
}
document.querySelector('#fill').onclick = async () => {
  await chrome.storage.local.set({pilgrims:read()});
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  if (!tab?.url?.startsWith('https://ttdevasthanams.ap.gov.in/')) return status('Open the TTD pilgrim details page first.');
  try {
    const selected = read().filter(p => p.enabled);
    if (!selected.length) return status('Select at least one pilgrim to fill.');
    const filled = await fillWithKeyboard(tab.id, selected);
    status(filled ? `Filled ${filled} field(s). Check every value.` : 'TTD controls were not found. Open the Pilgrim Details page.');
  } catch (error) { status(`Could not access the TTD form: ${error.message || 'unknown error'}`); }
};
